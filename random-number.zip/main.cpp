/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// A C++ Program to generate test cases for
// random number
#include<bits/stdc++.h>
using namespace std;


// Define the number of runs for the test data
// generated
#define RUN 5


// Define the range of the test data generated
#define MAX 10000000


int main()
{
// Uncomment the below line to store
// the test data in a file
// freopen("Test_Cases.in", "w", stdout);


// For random values every time
srand(time(NULL));


for (int i=1; i<=RUN; i++)
printf("%d\n", rand() % MAX);


// Uncomment the below line to store
// the test data in a file
//fclose(stdout);
return(0);
}